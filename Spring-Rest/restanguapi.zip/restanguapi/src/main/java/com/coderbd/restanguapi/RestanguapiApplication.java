package com.coderbd.restanguapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestanguapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestanguapiApplication.class, args);
	}
}
